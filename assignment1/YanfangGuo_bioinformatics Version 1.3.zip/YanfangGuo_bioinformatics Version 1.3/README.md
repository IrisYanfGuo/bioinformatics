## Assignment1: Aligning Sequences and detecting motifs

Author : Yanfang Guo

Department : Master of Applied Computer Science

Email: Yanfang.Guo@vub.be

Date : 2017/03/16 22:41



This is the version 1.3 of this project.

**Existing problems**

- In PSSM part, for different positions the probabilities of a gap are different. So a function that combines the gap penalty and probability is needed. Here I  used $tanh(frequency_{u,'-'})-0.8$ . It gave me some result, but I do not know whether this function is proper or not.(How to choose the right function??)
- ~~In PSSM, I tried to do recalculation and find the second largest score in the last column like local alignment, but the time cost of recalculation is much higher than that in Local alignment. I am still exploring that.~~
  - in version 1.3 , the problem is now fixed
- The output window in Jupyter is too small.Due to the long sequence, the score_mat and direc_mat have a long output that do not look good in jupyter. If you would like to see the intermediate data of score_mat and direc_mat,  I provide a copy of my python code in the src_python folder.


  ​