## Assignment2: GOR III secondary structure prediction

Author : Yanfang Guo

Department : Master of Applied Computer Science

Email: Yanfang.Guo@vub.be

Date : 2017/04/19 09:53

Version : 1.1


1. ./txtfile folder: some .txt files
   1. ./txtfile/dssp_predict.txt : the predict result for dssp_info.txt
   2. ./txtfile/stride_predict.txt : the predict result for stride_info.txt
   3. ./txtfile/stru_family_predict.csv : the predict structure, family prediction and q3,mcc score for dssp_info.txt
2. ./fasta folder : some ./fasta files